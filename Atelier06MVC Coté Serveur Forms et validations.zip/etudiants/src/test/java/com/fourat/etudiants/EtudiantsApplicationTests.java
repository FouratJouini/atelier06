package com.fourat.etudiants;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.fourat.etudiants.entities.Departement;
import com.fourat.etudiants.entities.Etudiant;
import com.fourat.etudiants.repos.EtudiantRepository;

@SpringBootTest
class ProduitsApplicationTests {
	@Autowired
	private EtudiantRepository EtudiantRepository;

	@Test
	public void testCreateEtudiant() {
		System.out.println("TestCreateEtudiant:");
		Etudiant prod = new Etudiant("salah salah", 22, new Date());
		EtudiantRepository.save(prod);
	}

	public void testFindEtudiant() {
		System.out.println("TestFindEtudiant:");
		Etudiant e = EtudiantRepository.findById(1L).get();
		System.out.println(e);
	}

	@Test
	public void testDeleteEtudiant() {
		System.out.println("TestDeleteEtudiant:");
		EtudiantRepository.deleteById((long) 44);
	}

	@Test
	public void testListerTousEtudiants() {
		System.out.println("TestListerTousEtudiants");
		List<Etudiant> etus = EtudiantRepository.findAll();
		for (Etudiant e : etus) {
			System.out.println(e);
		}
	}
	
	@Test
	public void testFindByNomEtudiant() {
		System.out.println("TestFindByNomEtudiant:");
		List <Etudiant> etuds = EtudiantRepository.findBynomEtu("test test");
		for (Etudiant e : etuds) {
			System.out.println(e);
		}
	}
	
	@Test
	public void testFindByNomEtudiantContains() {
		System.out.println("TestFindByNomEtudiantContains:");
		List <Etudiant> etuds = EtudiantRepository.findBynomEtuContains("test test");
		for (Etudiant e : etuds) {
			System.out.println(e);
		}
	}
	
	@Test
	public void testFindBynomEtuageEtu() {
		System.out.println("TestFindByNomEtuAgeEtu:");
		List <Etudiant> etuds = EtudiantRepository.findBynomEtuageEtu("salah salah", 22);
		for (Etudiant e : etuds) {
			System.out.println(e);
		}
	}
	
	@Test
	public void testFindBydepartement() {
		System.out.println("TestFindByDepartement:");
		Departement dept = new Departement();
		dept.setIdDept(1L);
		List <Etudiant> etuds = EtudiantRepository.findBydepartement(dept);
		for (Etudiant e : etuds) {
			System.out.println(e);
		}	
	}
	
	@Test
	public void testFindByidDept() {
		System.out.println("TestFindByIdDept:");
		List <Etudiant> etuds = EtudiantRepository.findBydepartementidDept(1L);
		for (Etudiant e: etuds) {
			System.out.println(e);
		}
	}
	@Test
	public void testFindByOrderByNomEtu() {
		System.out.println("testFindByOrderByNomEtu");
		List <Etudiant> etuds = EtudiantRepository.findByOrderByNomEtuAsc();
		for (Etudiant e: etuds) {
			System.out.println(e);
		}
	}
	
	@Test
	public void testTrierEtudiantsNomAge() {
		System.out.println("testTrierEtudiantsNomAge");
		List<Etudiant> etuds = EtudiantRepository.trierEtudiantsNomAge();
		for (Etudiant e: etuds) {
			System.out.println(e);
		}
	}
	
}