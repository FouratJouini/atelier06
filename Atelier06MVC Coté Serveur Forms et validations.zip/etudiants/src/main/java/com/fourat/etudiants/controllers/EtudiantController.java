package com.fourat.etudiants.controllers;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.fourat.etudiants.entities.Etudiant;
import com.fourat.etudiants.service.EtudiantService;
@Controller
public class EtudiantController {
	@Autowired
	EtudiantService EtudiantService;
	@RequestMapping("/showCreate")
	public String showCreate(ModelMap modelMap) {
		modelMap.addAttribute("etudiant", new Etudiant());
		modelMap.addAttribute("mode", "new");
		return "formEtudiant";
	}
	//créer un étudiant
	@RequestMapping("/saveEtudiant")
	public String saveEtudiant(@Valid Etudiant etudiant, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) return "formEtudiant";
	return "formEtudiant";
	}
	//lister les étudiants
	@RequestMapping("/ListeEtudiants")
	public String listeEtudiants(ModelMap modelMap)
	{
	List<Etudiant> etudiants = EtudiantService.getAllEtudiant();
	modelMap.addAttribute("etudiants", etudiants);
	return "listeEtudiants";
	}
	//supprimer un étudiant
	@RequestMapping("/supprimerEtudiant")
	public String supprimerEtudiant(@RequestParam("id") Long id,
	 ModelMap modelMap)
	{
	EtudiantService.deleteEtudiantById(id);
	List<Etudiant> etudiants = EtudiantService.getAllEtudiant();
	modelMap.addAttribute("etudiants", etudiants);
	return "listeEtudiants";
	}
	//modifier un étudiant
	@RequestMapping("/modifierEtudiant")
	public String editerEtudiant(@RequestParam("id") Long id,ModelMap modelMap)
	{
	Etudiant e= EtudiantService.getEtudiant(id);
	modelMap.addAttribute("etudiant", e);
	modelMap.addAttribute("mode", "edit");
	return "editerEtudiant";
	}
	//enregister la mise à jour dans la BD
	@RequestMapping("/updateEtudiant")
	public String updateEtudiant(@ModelAttribute("etudiant") Etudiant etudiant,
	@RequestParam("id") String id,
	@RequestParam("nomEtu") String info,
	@RequestParam("AgeEtu") String age,
	@RequestParam("dateIns") String date,
	ModelMap modelMap) throws ParseException
	{
		 SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
		 Date dateIns = dateformat.parse(String.valueOf(date));
		 long idetu = Long.parseLong(id);
		 long ageetu = Long.parseLong(age);
		 etudiant.setIdEtu(idetu);
		 etudiant.setAgeEtu(ageetu);
		 etudiant.setNomEtu(info);
		 etudiant.setDateInsEtu(dateIns);
		 EtudiantService.updateEtudiant(etudiant);
		 List<Etudiant> etudiants = EtudiantService.getAllEtudiant();
		 modelMap.addAttribute("etudiants", etudiants);
		return "listeEtudiants";
		}

}
