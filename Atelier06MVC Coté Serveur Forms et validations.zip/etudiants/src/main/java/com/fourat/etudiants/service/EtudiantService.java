package com.fourat.etudiants.service;
import java.util.List;
import com.fourat.etudiants.entities.Departement;
import com.fourat.etudiants.entities.Etudiant;
public interface EtudiantService {
	Etudiant saveEtudiant(Etudiant e);
	Etudiant updateEtudiant(Etudiant e);
	void deleteEtudiant(Etudiant e);
	void deleteEtudiantById(long id);
	Etudiant getEtudiant(long id);
	List <Etudiant> getAllEtudiant();
	List<Etudiant> findBynomEtu(String nom);
	List<Etudiant> findBynomEtuContains (String nom);
	List<Etudiant> findBynomEtuageEtu (String nom, long age);
	List<Etudiant> findBydepartement(Departement departement);
	List<Etudiant> findBydepartementidDept(Long idDept);
	List<Etudiant> findByOrderByNomEtuAsc();
	List<Etudiant> trierEtudiantsNomAge();
	
}
