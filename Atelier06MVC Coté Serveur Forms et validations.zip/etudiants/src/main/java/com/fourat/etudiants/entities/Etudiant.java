package com.fourat.etudiants.entities;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GenerationType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;
@Entity
public class Etudiant {
	//attributes
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private long idEtu;
	@NotNull
	@Size (min = 8, max = 50)
	private String nomEtu;
	@Min(value = 18)
	@Max(value = 30)
	private long ageEtu;
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date dateInsEtu;
	@ManyToOne
	private Departement departement;
	//constructor with no parameters
	public Etudiant() {
		super();
	}
	//constructor with parameters
	public Etudiant(String nomEtu, long ageEtu, Date dateInsEtu) {
		this.setNomEtu(nomEtu);
		this.setAgeEtu(ageEtu);
		this.setDateInsEtu(dateInsEtu);
	}
	//getters and setters;
	public long getIdEtu() {
		return this.idEtu;
	}
	public void setIdEtu(long id) {
		this.idEtu = id;
	}
	public String getNomEtu() {
		return nomEtu;
	}
	public void setNomEtu(String nomEtu) {
		this.nomEtu = nomEtu;
	}
	public long getAgeEtu() {
		return ageEtu;
	}
	public void setAgeEtu(long ageEtu) {
		this.ageEtu = ageEtu;
	}
	public Date getDateInsEtu() {
		return dateInsEtu;
	}
	public void setDateInsEtu(Date dateInsEtu) {
		this.dateInsEtu = dateInsEtu;
	}
	//toString
	public String toString() {
		return "Etudiant:\nId: "+this.idEtu+"\nNom: "+this.nomEtu+"\nAge: "+this.ageEtu+"\n Date Inscription: "+this.dateInsEtu;
	}
}
