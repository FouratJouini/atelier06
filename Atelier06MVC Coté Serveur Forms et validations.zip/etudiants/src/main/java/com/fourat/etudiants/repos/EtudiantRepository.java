package com.fourat.etudiants.repos;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fourat.etudiants.entities.Departement;
import com.fourat.etudiants.entities.Etudiant;
public interface EtudiantRepository extends JpaRepository<Etudiant, Long> {
	List<Etudiant> findBynomEtu(String nom);
	List<Etudiant> findBynomEtuContains (String nom);
	@Query ("select e from Etudiant e where e.nomEtu like %?1 and e.ageEtu > ?2")
	List<Etudiant> findBynomEtuageEtu (String nom, long age);
	@Query ("select e from Etudiant e where e.departement = ?1")
	List<Etudiant> findBydepartement(Departement departement);
	@Query ("select e from Etudiant e where e.departement.idDept = ?1")
	List<Etudiant> findBydepartementidDept(Long idDept);
	List<Etudiant> findByOrderByNomEtuAsc();
	@Query ("select e from Etudiant e order by e.nomEtu ASC, e.ageEtu DESC")
	List<Etudiant> trierEtudiantsNomAge();
}
