package com.fourat.etudiants.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fourat.etudiants.entities.Departement;
import com.fourat.etudiants.entities.Etudiant;
import com.fourat.etudiants.repos.EtudiantRepository;
@Service
public class EtudiantServiceImpl implements EtudiantService {
	@Autowired
	EtudiantRepository EtudiantRepository;
	
	@Override
	public Etudiant saveEtudiant(Etudiant e) {
		// TODO Auto-generated method stub
		return EtudiantRepository.save(e);
	}

	@Override
	public Etudiant updateEtudiant(Etudiant e) {
		// TODO Auto-generated method stub
		return EtudiantRepository.save(e);
	}

	@Override
	public void deleteEtudiant(Etudiant e) {
		// TODO Auto-generated method stub
		EtudiantRepository.delete(e);
	}

	@Override
	public void deleteEtudiantById(long id) {
		// TODO Auto-generated method stub
		EtudiantRepository.deleteById(id);
		
	}

	@Override
	public Etudiant getEtudiant(long id) {
		// TODO Auto-generated method stub
		return EtudiantRepository.findById(id).get();
	}

	@Override
	public List<Etudiant> getAllEtudiant() {
		// TODO Auto-generated method stub
		return EtudiantRepository.findAll();
	}

	@Override
	public List<Etudiant> findBynomEtu(String nom) {
		return EtudiantRepository.findBynomEtu(nom);
	}

	@Override
	public List<Etudiant> findBynomEtuContains(String nom) {
		// TODO Auto-generated method stub
		return EtudiantRepository.findBynomEtuContains(nom);
	}

	@Override
	public List<Etudiant> findBynomEtuageEtu(String nom, long age) {
		// TODO Auto-generated method stub
		return EtudiantRepository.findBynomEtuageEtu(nom, age);
	}

	@Override
	public List<Etudiant> findBydepartement(Departement departement) {
		// TODO Auto-generated method stub
		return EtudiantRepository.findBydepartement(departement);
	}

	@Override
	public List<Etudiant> findBydepartementidDept(Long idDept) {
		// TODO Auto-generated method stub
		return EtudiantRepository.findBydepartementidDept(idDept);
	}

	@Override
	public List<Etudiant> findByOrderByNomEtuAsc() {
		// TODO Auto-generated method stub
		return EtudiantRepository.findByOrderByNomEtuAsc();
	}

	@Override
	public List<Etudiant> trierEtudiantsNomAge() {
		// TODO Auto-generated method stub
		return EtudiantRepository.trierEtudiantsNomAge();
	}
	
}
